
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class HelloWorld {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws ParseException {
        System.out.println(Integer.parseInt("r5"));
    }
}
